# balaio.py

from app import app